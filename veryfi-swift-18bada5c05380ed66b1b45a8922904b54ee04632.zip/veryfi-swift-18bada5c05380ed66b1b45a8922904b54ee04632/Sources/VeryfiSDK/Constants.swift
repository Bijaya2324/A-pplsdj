//
//  File.swift
//  
//
//  Created by Diego Giraldo on 20/01/22.
//

import Foundation

struct Constants {
    static let packageVersion = "1.2.0"
}
